<html>
    <head>
        <meta charset="UTF-8">
        <title>Escolha</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
    </head>
    <body>
        <div class="container mt-3">
            <h2>Escolha qual será a forma</h2>
            <br>
            <a href="retangulo.php"><button class="btn btn-outline-dark btn-lg">Retângulo</button></a>
            <br>
            <br>
           <a href="circulo.php"><button class="btn btn-outline-dark btn-lg">Círculo</button></a>
        </div>
    </body>
</html>

