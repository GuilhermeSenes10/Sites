<html>
    <head>
        <meta charset="UTF-8">
        <title>Resultado Círuculo</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
    </head>
    <body>
        <div class="container mt-3 form-control">
        <?php
        $num1 = $_POST['raio'];
        
        $area = 3.14 * ($num1 * $num1);
            echo "a área do círculo é $area <br>";
            
        $peri = 2 * 3.14 * $num1;
            echo "o perímetro do círculo é $peri";
        
        ?>
        <br>
        <form action="circulo.php" method="post">
        <button type="submit" class="btn btn-outline-dark btn-lg">Voltar</button>
        </form>
        <form action="index.php" method="post">
        <button type="submit" class="btn btn-outline-dark btn-lg">Escolher forma</button>
        </form>
        </div>
    </body>
</html>
