<html>
    <head>
        <meta charset="UTF-8">
        <title>Retângulo</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
    </head>
    <body>
        <h2>Calcular a área e o perímetro do Retângulo</h2>
        <form action="calculoretangulo.php" method="post">
            <div class="mb-3 mt-3">
                <label for="base">Informe a base do retângulo</label>
                <input id="base" type="number" class="form-control" placeholder="Digite aqui" name="base"/>
            </div>
            <div class="mb-3 mt-3">
                <label for="altura">Informe a altura do retângulo</label>
                <input id="altura" type="number" class="form-control" placeholder="Digite aqui" name="altura"/>
            </div>
            <button type="submit" class="btn btn-outline-dark btn-lg">Calcular</button>
        </form>
        <form action="index.php" method="post">
        <button type="submit" class="btn btn-outline-dark btn-lg">Escolher forma</button>
        </form>
    </body>
</html>
