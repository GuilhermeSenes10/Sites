
<html>
    <head>
        <meta charset="UTF-8">
        <title>Círculo</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
    </head>
    <body>
        <h2>Calcular a área do círculo</h2>
        <form action="calculocirculo.php" method="post">
            <div class="mb-3 mt-3">
                <label for="raio">Informe o raio do círculo </label>
                <input id="raio" type="number" class="form-control" placeholder="Digite aqui" name="raio"/>
            </div>
            <button type="submit" class="btn btn-outline-dark btn-lg">Calcular</button>
        </form>
        <form action="index.php" method="post">
        <button type="submit" class="btn btn-outline-dark btn-lg">Escolher forma</button>
        </form>
    </body>
</html>
