<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
    </head>
    <body>
        <?php
        $genero = $_POST['genero'];
        $estado = $_POST['estado'];
        
        echo "Gênero: $genero <br/>";
        echo "Estado: $estado <br/>";
        ?>
        <a href="index.php">Voltar</a>
    </body>
</html>
