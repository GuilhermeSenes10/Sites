<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Other/html.php to edit this template
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="estilo.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <header>
            <img src="logoo.png" alt=""width="800"/>

        </header>
        <section>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a class="ativo"href="historia.php">Histórico do Minecraft</a></li>
                    <li><a href="galeria.php">Galeria de fotos</a></li>   
                    <li><a href="requisitos.php">Requisitor de Hardware</a></li>
                    <li><a href="faleconosco.php">Fale conosco</a></li>
                </ul>
            </nav>
            <article>
                <h2>HISTORIA DO MNECRAFT</h2>
                <p>Um dos maiores fenômenos na história dos games completou uma década de existência em 17 de maio de 2019. Minecraft revolucionou a indústria para os criadores de conteúdo de games e, tendo o YouTube como grande aliado, se tornou um dos games mais jogados de toda a história.</p>

                <p>Tudo começou com Markus Persson e um game de construção e gerenciamento com visão isométrica que após um longo percurso, diferentes empresas e o feedback de muitos jogadores, se tornou o grande fenômeno que é hoje.</p>

                <p>Para saber o restante da história, confira o vídeo abaixo em homenagem aos dez anos de Minecraft:</p>
                <iframe width="560" height="315" src="https://www.youtube.com/embed/Hu4PXTYx16M" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </article>
        </section>
        <footer>
            <p>Desenvolvido por Renzi</p>
        </footer>
    </body>
</html>
