<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Other/html.php to edit this template
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="estilo.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <header>
            <img src="logoo.png" alt=""width="800"/>

        </header>
        <section>
            <nav>
                <ul>
                    <li><a  href="index.php">Home</a></li>
                    <li><a href="historia.php">Histórico do Minecraft</a></li>
                    <li><a class="ativo"href="galeria.php">Galeria de fotos</a></li>   
                    <li><a href="requisitos.php">Requisitor de Hardware</a></li>
                    <li><a href="faleconosco.php">Fale conosco</a></li>
                </ul>
            </nav>
            <article>
  <h2>Mine</h2>  
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
          <img src="foto001.jpg" alt="" style="width: 1000px">
      </div>

      <div class="item">
          <img src="foto002.jpg" alt="" style="width: 1000px">
      </div>
    
      <div class="item">
          <img src="foto003.jpg" alt="" style="width: 1000px">
      </div>
        
      <div class="item">
          <img src="foto004.jpg" alt="" style="width: 1000px">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
</div>
            </article>
        </section>
        <footer>
            <p>Desenvolvido por Renzi</p>
        </footer>
    </body>
</html>
