<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Other/html.php to edit this template
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="estilo.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <header>
            <img src="logoo.png" alt=""width="800"/>

        </header>
        <section>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="historia.php">Histórico do Minecraft</a></li>
                    <li><a href="galeria.php">Galeria de fotos</a></li>   
                    <li><a class="ativo"href="requisitos.php">Requisitor de Hardware</a></li>
                    <li><a href="faleconosco.php">Fale conosco</a></li>
                </ul>
            </nav>
            <article>
                <h2>Requisitos Mínimos</h2>
                <table>
                    
                    <tr><td>Processador:</td>
                        <td>Intel Core i3-3210 3.2 GHz / AMD A8-7600 APU 3.1 GHz</td></tr>
                    <tr><td>Memória RAM:</td>
                        <td>4 GB</td></tr>
                    <tr><td>Placa de vídeo integrada:</td>
                        <td>Intel HD Graphics 4000 (Ivy Bridge) ou AMD Radeon R5 series (Kaveri line)</td></tr>
                    <tr><td>Placa de vídeo dedicada:</td>
                        <td>Nvidia GeForce 400 Series or AMD Radeon HD 7000 series</td></tr>
                    <tr><td>Sistemas Operacionas:</td>
                        <td>Windows 7 ou mais recente; macOS 10.9 Maverick ou mais recente; Linux: qualquer versão de 64 bits acima de 2014;</td></tr>
                    <tr><td>Espaço em disco:</td>
                        <td>4 GB</td></tr>
                    <tr><td colspan="2">Conectividade com internet </td></tr>
                      
                </table>
                
                      <h2>Requisitos Recomendados</h2>
                <table>
                    
                    <tr><td>Processador:</td>
                        <td>Intel Core i5-4690 3.5GHz / AMD A10-7800 APU 3.5</td></tr>
                    <tr><td>Memória RAM:</td>
                        <td>8 GB</td></tr>
                    <tr><td>Placa de vídeo dedicada:</td>
                        <td>GeForce 700 Series ou AMD Radeon Rx 200 Series</td></tr>
                    <tr><td>Sistemas Operacionas:</td>
                        <td>Windows 10; macOS 10.12 Sierra ou mais recente; Linux: qualquer versão de 64 bits acima de 2014;</td></tr>
                    <tr><td>Espaço em disco:</td>
                        <td>4 GB</td></tr>
                    <tr><td colspan="2">Conectividade com internet </td></tr>
                      
                </table>
            </article>
        </section>
        <footer>
            <p>Desenvolvido por Renzi</p>
        </footer>
    </body>
</html>
