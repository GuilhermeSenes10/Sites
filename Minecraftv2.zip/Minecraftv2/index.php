<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Other/html.php to edit this template
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="estilo.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <header>
            <img src="logoo.png" alt=""width="800"/>

        </header>
        <section>
            <nav>
                <ul>
                    <li><a class="ativo" href="index.php">Home</a></li>
                    <li><a href="historia.php">Histórico do Minecraft</a></li>
                    <li><a href="galeria.php">Galeria de fotos</a></li>   
                    <li><a href="requisitos.php">Requisitor de Hardware</a></li>
                    <li><a href="faleconosco.php">Fale conosco</a></li>
                </ul>
            </nav>
            <article>
                <h2>O MUNDO É TEU PARA O CRIARES</h2>

                <p>Prepara-te para uma aventura de possibilidades infinitas à medida que constróis,
                    mineras, combates criaturas e exploras a paisagem sempre em mudança do Minecraft.</p>

                <h2>HÁ SEMPRE ALGUMA COISA NOVA</h2>

                <p>Novos espaços, ferramentas e localizações estão à tua disposição para explorares,
                    graças às nossas atualizações periódicas. Vê as últimas novidades.</p>
            </article>
        </section>
        <footer>
            <p>Desenvolvido por Renzi</p>
        </footer>
    </body>
</html>
