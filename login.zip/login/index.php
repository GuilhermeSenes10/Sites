<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
        <title>Login</title>
    </head>
    <body>
        <div class="container mt-3">
            <h2>Login</h2> 
            <form action="#" method="post">
                <div class="mb-3 mt-3">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" placeholder="Digite seu email" name="email">
                </div>    
                <div class="mb-3 mt-3">
                    <label for="senha">Senha:</label>
                    <input type="password" class="form-control" id="senha" placeholder="Digite sua senha" name="senha">
                </div>    
                <div class="mb-3 mt-3">
                    <label class="form-check-label">
                        <input type="checkbox" class="form-check-input" name="lembrete">
                        Esqueci a senha
                    </label>
                </div> 
                <button type="submit" class="btn btn-primary">Login</button>
            </form>
        </div>
    </body>
</html>
