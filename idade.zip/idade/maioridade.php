<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
    </head>
    <body>
        <div class="container mt-3 form-control">
        <?php
        $num1 = $_POST['idade'];
        if($num1>=18){
            echo "Você é maior de idade e já pode ser preso!";
        } else {
            echo "Você não é maior de idade";
        }
        ?>
        <br>
        <form action="index.php" method="post">
        <button type="submit" class="btn btn-outline-dark btn-lg">Voltar</button>
        </form>
        </div>
    </body>
</html>