<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
    </head>
    <body>
        <div class="container mt-3">
            <h2>Sou maior de idade?</h2>
            <form action="maioridade.php" method="post">
                <div class="mb-3 mt-3">
                    <label for="idade">Informe sua idade: </label>
                    <input id="idade" type="number" class="form-control" placeholder="Digite aqui" name="idade"/>
                </div>
                <button type="submit" class="btn btn-outline-dark btn-lg">Ler</button>
            </form>
        </div>
    </body>
</html>