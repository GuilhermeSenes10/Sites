<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
    </head>
    <body>
        <div class="container mt-3 form-control">
        <?php
        $num1 = $_POST['gasolina'];
        $num2 = $_POST['etanol'];
        
        if($num2>$num1 * 0.7){
            echo "Gasolina é a melhor opção";
        } elseif ($num2==$num1 * 0.7){
            echo "Os dois estão o mesmo preço, mas a gasolina é melhor";
        } if ($num2<$num1 * 0.7) {
            echo "Etanol é a melhor opção";
        }
        ?>
        <br>
        <form action="index.php" method="post">
        <button type="submit" class="btn btn-outline-dark btn-lg">Voltar</button>
        </form>
        </div>
    </body>
</html>
