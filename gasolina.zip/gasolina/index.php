<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
    </head>
    <body>
        <div class="container mt-3">
            <h2>Gasolina ou Etanol?</h2>
            <form action="maisvantajoso.php" method="post">
                <div class="mb-3 mt-3">
                    <label for="numero1">Informe o preço da gasolina: </label>
                    <input id="gasolina" type="number" class="form-control" placeholder="Digite aqui" name="gasolina"/>
                </div>    
                <div class="mb-3 mt-3">
                    <label for="numero2">Informe o preço do etanol: </label>
                    <input id="etanol" type="number" class="form-control" placeholder="Digite aqui" name="etanol"/>
                </div>
                <button type="submit" class="btn btn-outline-dark btn-lg">Comprarar</button>
            </form>
        </div>
    </body>
</html>
